// usage: ROOM=ice|sand node runl2.js <out.png>
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const fs=require('fs'),path=require('path'),http=require('http');
const SITE=path.resolve(__dirname,'site'),THREE_DIR='/home/claude/work/node_modules/three';
(async()=>{
  const srv=http.createServer((req,res)=>{const u=decodeURIComponent(req.url.split('?')[0]);const f=path.join(SITE,u);
    if(!f.startsWith(SITE)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);res.end();return;}
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});fs.createReadStream(f).pipe(res);}).listen(0);
  const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--no-sandbox','--autoplay-policy=no-user-gesture-required']});
  const ctx=await b.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1});
  const errs=[];const pg=await ctx.newPage();
  pg.on('pageerror',e=>errs.push('PAGEERROR '+e.message.slice(0,500)));pg.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text().slice(0,700));});
  await pg.route('https://cdn.jsdelivr.net/npm/three@0.169.0/**',r=>{const p=new URL(r.request().url()).pathname.replace('/npm/three@0.169.0/','');const f=path.join(THREE_DIR,p);
    if(fs.existsSync(f))r.fulfill({status:200,contentType:'text/javascript',body:fs.readFileSync(f)});else r.abort();});
  await pg.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  const t0=Date.now();
  await pg.goto('http://localhost:'+srv.address().port+'/'+(process.env.PAGE||'l2.html?capture'),{waitUntil:'domcontentloaded'});
  try{
    await pg.waitForFunction(()=>window.RV&&window.RV.ready,null,{timeout:240000});await pg.evaluate(()=>window.RV.ready);console.log('boot ms',Date.now()-t0);
    const sand=process.env.ROOM==='sand';
    await pg.evaluate((sand)=>{RV.setTime(20);RV.hold(sand?RV.ev('P_FIN'):1);RV.sim(0.1,40);RV.step(0.05);},sand);
    console.log(String(await pg.evaluate((sand)=>sand?JSON.stringify(RV.sandCave(0)):JSON.stringify(RV.cave(0)),sand).catch(e=>'KO '+e.message.slice(0,300))).slice(0,300));
    for(let i=0;i<6;i++){await pg.evaluate(()=>RV.step(0.6));}
    console.log(await pg.evaluate(()=>RV.ev('JSON.stringify({k:+CAVE.k.toFixed(2),n:CAVE.n,on:CAVE.on,calls:renderer.info.render.calls,progs:renderer.info.programs.length})')));
    await pg.evaluate(()=>RV.step(0.05));
    console.log(await pg.evaluate(()=>RV.ev('JSON.stringify({pos:camera.position.toArray().map(v=>+v.toFixed(2)),tgt:camTgt.toArray().map(v=>+v.toFixed(2)),fov:camera.fov,view:camera.view,expo:renderer.toneMappingExposure,bloom:[bloom.strength,bloom.threshold,bloom.radius],b0:CAVE.cv.books[0].holder.position.toArray().map(v=>+v.toFixed(2)),psx:[pointer.sx,pointer.sy],VW:VW,VH:VH})')));
    await pg.screenshot({path:process.argv[2],timeout:240000});
  }catch(e){console.log('RUN ERROR',e.message.slice(0,500));}
  console.log('errors:',errs.length?errs.slice(0,6):'none');
  await b.close();srv.close();
})();
