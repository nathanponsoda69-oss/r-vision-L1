// usage: node run.js <page?query> <out-prefix> "<t1,t2,...>" [view,...]
const {chromium}=require('/opt/npm-tools/node_modules/playwright');
const fs=require('fs'),path=require('path'),http=require('http');
const SITE=path.resolve(__dirname,'site'),THREE_DIR=path.resolve(__dirname,'node_modules/three');
(async()=>{
  const srv=http.createServer((req,res)=>{const u=decodeURIComponent(req.url.split('?')[0]);const f=path.join(SITE,u);
    if(!f.startsWith(SITE)||!fs.existsSync(f)){res.writeHead(404);res.end();return;}
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});fs.createReadStream(f).pipe(res);}).listen(0);
  const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--no-sandbox']});
  const ctx=await b.newContext({viewport:{width:+(process.env.VW||960),height:+(process.env.VH||540)},deviceScaleFactor:1});
  const errs=[];const pg=await ctx.newPage();
  pg.on('pageerror',e=>errs.push('PAGEERROR '+e.message));pg.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+' '+m.text().slice(0,600));});
  await pg.route('https://cdn.jsdelivr.net/npm/three@0.169.0/**',r=>{const p=new URL(r.request().url()).pathname.replace('/npm/three@0.169.0/','');const f=path.join(THREE_DIR,p);
    if(fs.existsSync(f))r.fulfill({status:200,contentType:'text/javascript',body:fs.readFileSync(f)});else r.abort();});
  await pg.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());
  await pg.goto('http://localhost:'+srv.address().port+'/'+process.argv[2],{waitUntil:'domcontentloaded'});
  try{
    await pg.waitForFunction(()=>window.T&&window.T.ok,null,{timeout:120000});
    const ts=(process.argv[4]||'3').split(',').map(Number),views=(process.argv[5]||'0').split(',');
    for(const v of views)for(const t of ts){await pg.evaluate(([v,t])=>window.T.shot(v,t),[v,t]);await pg.screenshot({path:process.argv[3]+'_v'+v+'_t'+t+'.png',timeout:240000});}
  }catch(e){console.log('RUN ERROR',e.message.slice(0,400));}
  console.log('errors:',errs.length?errs.slice(0,8):'none');
  await b.close();srv.close();
})();
