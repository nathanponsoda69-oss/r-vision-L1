# Intègre les deux salles d'essai (glacier, donjon de lave) dans l2.html, à la place de l'ancien bloc « donjon ».
import re,sys
W='/home/claude/work/'
src=open(W+'l2/l2_orig.html',encoding='utf-8').read()
gl=open(W+'site/essai_glacier.html',encoding='utf-8').read()
lv=open(W+'site/essai_lave.html',encoding='utf-8').read()
def cut(s,a,b):
    i=s.index(a);j=s.index(b,i);return s[i:j]
def R(s,a,b,n=1):
    assert s.count(a)==n,(s.count(a),a[:80]);return s.replace(a,b)
PRE="""  const TIER=MOBILE?0:2,PI=Math.PI,TAU=PI*2,clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),lerp=(a,b,t)=>a+(b-a)*t,smooth=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
  function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
  const V3=(x,y,z)=>new THREE.Vector3(x,y,z),scene=root;
"""
# ---------- glacier ----------
g=cut(gl,"/* ───────── bruit (CPU) pour modeler la grotte ───────── */","/* ───────── rendu ───────── */")
g=R(g,"[[-.6,-3.4,.75],[1.9,-1.2,.5],[-2.6,-7.2,.9],[2.9,5.2,.6]]","[[-4.0,-6.0,.75],[3.4,-4.8,.5],[-2.6,-7.6,.9],[2.9,5.2,.6]]")
GL="/* ═══ salle de cours « glacier » (droit) : voûte de glace à cupules, lumière du bloc de glace, faisceaux mouvants ═══ */\nfunction rvRoomGlacier(root){\n"+PRE+"  const rnd=mulberry(20261114),U={uTime:{value:0}};\n"+g+"\n  build();\n  return {U,SKY,LDIR};\n}\n"
# ---------- donjon de lave ----------
l=cut(lv,"const SUN=V3(","/* ───────── rendu ───────── */")
l=R(l,"const U={uTime:{value:0},uPx:{value:300},uSun:{value:SUN},uF:{value:HIT},uFogC:{value:FOGC},uFogD:{value:FOGD}};","const FOGC=new THREE.Color(0x0b0503),FOGD=.034;\nconst U={uTime:{value:0},uPx:{value:300},uSun:{value:SUN},uF:{value:HIT},uFogC:{value:FOGC},uFogD:{value:FOGD}};")
l=R(l,"*lg*lf*3.4;}","*lg*lf*3.4;\n        {float fd=length(vViewPosition);outgoingLight=mix(outgoingLight,vec3(.0035,.0015,.001),1.-exp(-fd*fd*.034*.034));}}")
l=R(l,"[[-1.7,-5.2,.4],[1.5,-1.4,-.3],[-1.5,2.9,.25]].forEach((p,i)=>{mk(pedG,st,","[].forEach((p,i)=>{mk(pedG,st,")
l=R(l,"pile(-.4,-1.8,6,.6);","")
l=R(l,"for(const z of [-3.2,5.2]){mk(new THREE.BoxGeometry(1.5,.05,1.1)","for(const z of [-7.4,5.6]){mk(new THREE.BoxGeometry(1.5,.05,1.1)")
i=l.index("function captureEnv(){");j=l.index("\n",l.index("const pm=new THREE.PMREMGenerator",i))
l=l[:i]+"""function captureEnv(scn){const rt=new THREE.WebGLCubeRenderTarget(TIER?128:64,{type:THREE.HalfFloatType}),cc=new THREE.CubeCamera(.1,60,rt);cc.position.set(0,2.6,-2);root.add(cc);cc.update(renderer,scn);root.remove(cc);
  const pm=new THREE.PMREMGenerator(renderer),tex=pm.fromCubemap(rt.texture).texture;rt.dispose();pm.dispose();
  root.traverse(o=>{const m=o.material;if(m&&m.isMeshStandardMaterial&&m.metalness>.5){m.envMap=tex;m.needsUpdate=true;}});}"""+l[j:]
assert 'scene.environment' not in l and 'Q.' not in l and 'camera' not in l.replace('cameraPosition','').replace('CubeCamera','')
LV="/* ═══ salle de cours « donjon de lave » (finance) : pierre en volume, vitraux, douves, mobilier ═══ */\nfunction rvRoomLava(root){\n"+PRE+"  const rnd=mulberry(20261115);\n"+l+"""
  build();buildWindows();buildLava();buildLights();buildGlow();buildProps();
  const pedGeo=latheOf([[0,0],[.46,0],[.48,.1],[.37,.17],[.3,.24],[.27,.3],[.25,.84],[.29,.9],[.38,.95],[.42,.98],[.42,1.06],[.36,1.09],[0,1.09]].map(p=>[p[0],p[1]/1.09]),8);
  return {U,tick(t){tickBubbles(t);tickLights(t);},env:captureEnv,amber,pedGeo,stone:stoneMat(0x8c857c)};
}
"""
# ---------- câblage dans buildBookCave ----------
a="  /* ══════════ L2 · salles de cours : donjon de lave (finance) · donjon pris dans un glacier (droit) ══════════"
i=src.index(a);j=src.index("  const shardM=ice?",i)
WIRE="""  /* ══════════ L2 · salles de cours : donjon de lave (finance) · grotte de glacier (droit) ══════════
     Les deux salles sont construites par rvRoomLava / rvRoomGlacier ; ici on les branche sur les livres, la caméra et les réglages de rendu. */
  const FXD=[];
  { root.children.filter(o=>o.isMesh).slice(0,ice?3:2).forEach(o=>{o.visible=false;});          // ancienne voûte, ancien dallage, anciennes stalactites
    torches.forEach(t=>{t.g.visible=false;t.L.userData.caveI=0;});
    const ROOM=ice?rvRoomGlacier(root):rvRoomLava(root);
    if(ice){lights.forEach(l=>{if(l.isHemisphereLight){l.color.set('#6fa8dc');l.groundColor.set('#0a1626');l.userData.caveI=1.9;}
        else if(l.isDirectionalLight){l.color.set('#a8dcff');l.position.copy(ROOM.SKY);l.target.position.copy(ROOM.SKY).addScaledVector(ROOM.LDIR,5);l.userData.caveI=0.9;}});
      for(const m of [enclM,pilM]){m.roughness=0.34;m.clearcoat=0.25;m.clearcoatRoughness=0.4;m.specularIntensity=0.3;m.envMapIntensity=0.6;}}
    else{lights.forEach(l=>{if(!l.isPointLight)l.userData.caveI=0;});
      /* livres pris dans l'ambre, sur un piédestal de pierre */
      books.forEach((b,i)=>{b.g.remove(b.chunk);const am=ROOM.amber(0,0,0,0,3.7+i*5.3);am.position.set(0,0,0);am.rotation.set(0,0,0);am.scale.set(0.66,0.8,0.36);const w=new THREE.Group();w.add(am);b.g.add(w);b.chunk=w;
        b.ped.geometry=ROOM.pedGeo;b.ped.material=ROOM.stone;});}
    const _s=new THREE.Vector2();let envDone=false;
    FXD.push((T,dt,inside)=>{if(!inside)return;ROOM.U.uTime.value=T;if(ROOM.U.uPx)ROOM.U.uPx.value=renderer.getDrawingBufferSize(_s).y/(2*Math.tan(camera.fov*Math.PI/360));
      if(ROOM.tick)ROOM.tick(T);if(!envDone&&ROOM.env){envDone=true;ROOM.env(scn);}});
    /* — les livres restent lisibles dans la pénombre — */
    books.forEach(b=>b.holder.traverse(o=>{const m=o.material;if(m&&m.isMeshStandardMaterial&&m!==b.coverM&&m!==enclM&&!m.userData.rvGlow){m.userData.rvGlow=1;m.emissive=m.color.clone();m.emissiveIntensity=0.22;if(m.map)m.emissiveMap=m.map;m.needsUpdate=true;}}));
  }
"""
src=src[:i]+WIRE+src[j:]
src=R(src,"function buildBookCave(kind){",GL+LV+"function buildBookCave(kind){")
src=R(src,"import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';","import { mergeGeometries, mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';")
src=R(src,"if(ice)b.chunk.scale.set(1-0.18*melt,1-0.12*melt,1-0.3*melt);else b.chunk.scale.set(1-0.12*melt,1-0.35*melt,1-0.12*melt);","if(ice)b.chunk.scale.set(1-0.18*melt,1-0.12*melt,1-0.3*melt);else b.chunk.scale.set(1-0.05*melt,1-0.05*melt,1-0.08*melt);")
src=R(src,"scn.background=new THREE.Color(ice?'#22323d':'#0c0806');","scn.background=new THREE.Color(ice?'#01040a':'#050302');")
src=R(src,":new THREE.MeshStandardMaterial({color:new THREE.Color('#9c7a55'),roughness:1,metalness:0,flatShading:true});",":new THREE.MeshStandardMaterial({color:new THREE.Color('#e08a1c'),roughness:0.25,metalness:0,flatShading:true,emissive:new THREE.Color('#7a3206')});")
src=R(src,"fog:new THREE.Color(ice?'#0c1a26':'#170a06'),fogD:ice?0.022:0.026,","fog:new THREE.Color(ice?'#06121f':'#0b0503'),fogD:ice?0.022:0.026,")
src=R(src,"mistK:ice?0.12:0.16,mistH:ice?2.8:2.8,expo:ice?0.72:0.86,bloom:ice?[0.3,0.95]:[0.17,0.97],","mistK:ice?0.03:0.04,mistH:ice?2.8:2.8,expo:ice?0.62:1.0,bloom:ice?[0.5,0.82]:[0.42,0.9],")
src=R(src,"view:{pos:new THREE.Vector3(1.8,2.5,10.6),tgt:new THREE.Vector3(0.8,2.2,-1.8),top:new THREE.Vector3(0.8,5.4,8.0)}};","view:ice?{pos:new THREE.Vector3(0.4,1.6,8.25),tgt:new THREE.Vector3(3.3,2.75,-3.0),top:new THREE.Vector3(0.4,3.2,7.5)}:{pos:new THREE.Vector3(0.6,1.9,9.6),tgt:new THREE.Vector3(0.1,1.9,-6),top:new THREE.Vector3(0.6,5.4,8.8)}};")
src=R(src,"(CAVE.kind==='sand'?'ENSABLÉ':'PRIS DANS LA GLACE')","(CAVE.kind==='sand'?'PRIS DANS L’AMBRE':'PRIS DANS LA GLACE')")
src=R(src,"const where=mode==='ice'?'CAVERNE DE GLACE':mode==='sand'?'GROTTE AUX TORCHES':'MATIÈRE';","const where=mode==='ice'?'GROTTE DE GLACIER':mode==='sand'?'DONJON DE LAVE':'MATIÈRE';")
src=R(src,"?'ENSABLÉ':'GELÉ')}</span>","?'AMBRE':'GELÉ')}</span>")
src=R(src,"b.coverM.map=b.tex;b.coverM.needsUpdate=true;","b.coverM.map=b.tex;if(b.coverM.emissiveMap)b.coverM.emissiveMap=b.tex;b.coverM.needsUpdate=true;")
# livres mieux éclairés dans l'ambre : la couverture rayonne un peu
src=R(src,"b.ped.geometry=ROOM.pedGeo;b.ped.material=ROOM.stone;});}","b.ped.geometry=ROOM.pedGeo;b.ped.material=ROOM.stone;});}\n    books.forEach(b=>{b.coverM.emissive=new THREE.Color('#ffffff');b.coverM.emissiveMap=BOOK_BLANK;b.coverM.emissiveIntensity=ice?0.42:0.3;});")
# glacier : les livres se répartissent de part et d'autre du faisceau (certains dans la lumière, d'autres dans l'ombre)
src=R(src,"const rr=3.3+(i%2)*0.55;const x=Math.sin(a)*rr-0.5,z=-Math.cos(a)*rr+0.2;","const rr=3.3+(i%2)*0.55;const x=Math.sin(a)*rr+(ice?1.0:-0.5),z=-Math.cos(a)*rr+(ice?0.5:0.2);")
open(W+'l2/site/l2.html','w',encoding='utf-8').write(src)
print('ok',len(src))
