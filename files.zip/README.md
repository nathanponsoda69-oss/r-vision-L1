# 📚 Sites de Révision — L1 Droit-Finance · Lyon 3

Sites de révision interactifs pour L1 Droit-Finance.

## 🌐 Accéder aux sites

**→ [Ouvrir le portail](https://TON-PSEUDO.github.io/revision-l1/)**

| Site | Matière | Lien direct |
|------|---------|-------------|
| Mariage & Divorce | Droit Civil | [droit-civil.html](https://TON-PSEUDO.github.io/revision-l1/droit-civil.html) |
| L'Ancien Régime | Histoire du Droit | [histoire-1.html](https://TON-PSEUDO.github.io/revision-l1/histoire-1.html) |
| La Révolution française | Histoire du Droit | [histoire-2.html](https://TON-PSEUDO.github.io/revision-l1/histoire-2.html) |
| Du Directoire à 1848 | Histoire du Droit | [histoire-3.html](https://TON-PSEUDO.github.io/revision-l1/histoire-3.html) |
| Marchés & Marchandisation | Économie | [marches.html](https://TON-PSEUDO.github.io/revision-l1/marches.html) |

> Remplace `TON-PSEUDO` par ton nom d'utilisateur GitHub.

## 📦 Contenu
- Quiz interactifs (QCM, Vrai/Faux, questions ouvertes)
- Flashcards avec suivi de progression
- Schémas interactifs cliquables
- Système XP + 60 succès + portes secrètes
- Jurisprudence commentée, doctrine, actualité 2025-2026

## 🚀 Déploiement GitHub Pages

1. Crée un repo public nommé `revision-l1`
2. Upload tous les fichiers de ce dossier
3. `Settings` → `Pages` → `Deploy from branch: main / root`
4. URL disponible en 30 secondes : `https://TON-PSEUDO.github.io/revision-l1/`
